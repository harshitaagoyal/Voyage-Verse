const countryCategories = {
    beaches: ["Maldives", "Hawaii", "Goa", "Bahamas", "Bali"],
    mountains: ["Switzerland", "Nepal", "Bhutan", "Colorado", "Rocky Mountains"],
    family: ["Disneyland", "Singapore", "London", "Tokyo", "Sydney"],
    couple: ["Paris", "Venice", "Santorini", "Prague", "Kyoto"],
    "pets-allowed": ["Amsterdam", "Berlin", "Austin", "Seattle", "Portland"],
    "pets-not-allowed": ["Dubai", "Beijing", "Moscow", "Riyadh", "Cairo"],
};


let userWishlist = [];
let originalWishlist = [];


const wishlist = document.getElementById("wishlist");
const countryInput = document.getElementById("countryInput");
const addButton = document.getElementById("addButton");
const filterButtons = document.querySelectorAll(".filter-btn");


addButton.addEventListener("click", function () {
    const countryName = countryInput.value.trim();

    if (countryName) {
        userWishlist.push(countryName);
        originalWishlist = [...userWishlist];
        renderWishlist(userWishlist);
        countryInput.value = "";
    }
});


function renderWishlist(items) {
    wishlist.innerHTML = "";
    items.forEach((country) => {
        const li = document.createElement("li");


        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.className = "checkbox";


        checkbox.addEventListener("change", function () {
            if (checkbox.checked) {
                li.classList.add("completed");
            } else {
                li.classList.remove("completed");
            }
        });


        const text = document.createTextNode(country);


        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "Delete";
        deleteBtn.className = "delete-btn";
        deleteBtn.addEventListener("click", function () {
            userWishlist = userWishlist.filter((item) => item !== country);
            originalWishlist = [...userWishlist];
            renderWishlist(userWishlist);
        });


        li.appendChild(checkbox);
        li.appendChild(text);
        li.appendChild(deleteBtn);


        wishlist.appendChild(li);
    });
}


filterButtons.forEach((button) => {
    button.addEventListener("click", function () {
        const filter = button.getAttribute("data-filter");


        const filteredCountries = originalWishlist.filter((country) =>
            countryCategories[filter]?.includes(country)
        );

        renderWishlist(filteredCountries);
    });
});


document.body.addEventListener("click", function (e) {
    if (!e.target.matches(".filter-btn")) {
        renderWishlist(originalWishlist);
    }
});

