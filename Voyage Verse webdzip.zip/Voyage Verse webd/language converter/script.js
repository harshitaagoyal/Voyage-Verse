const apiKey = 'J7yjSSCiLem8pgeqjb8MyhH8YGX6hlPR';

document.getElementById('translateButton').addEventListener('click', () => {
    const sourceText = document.getElementById('sourceText').value;
    const sourceLang = document.getElementById('sourceLang').value;
    const targetLang = document.getElementById('targetLang').value;

    if (!sourceText.trim()) {
        alert('Please enter text to translate.');
        return;
    }

    const url = `https://apilayer.com/marketplace/language_translation-api`;
    const data = {
        q: sourceText,
        source: sourceLang,
        target: targetLang,
        format: 'text',
    };

    fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    })
        .then((response) => response.json())
        .then((data) => {
            const translatedText = data.data.translations[0].translatedText;
            document.getElementById('translatedText').value = translatedText;
        })
        .catch((error) => {
            console.error('Error:', error);
            alert('Translation failed. Please check the console for more details.');
        });
});
