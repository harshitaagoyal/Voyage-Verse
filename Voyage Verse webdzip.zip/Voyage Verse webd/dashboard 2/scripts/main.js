const UNSPLASH_ACCESS_KEY = "z7ZWrFMcAW_DZIwnf2VdRIXkqm-xOfmmAWBpZZ--m3A";


function getQueryParameter(name) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name);
}


async function fetchAndDisplayImages(query) {
    const resultsContainer = document.getElementById("results-container");
    const resultsTitle = document.getElementById("results-title");

    resultsTitle.innerText = `Results for "${query}"`;

    const apiUrl = `https://api.unsplash.com/search/photos?query=${query}&per_page=12&client_id=${UNSPLASH_ACCESS_KEY}`;

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) throw new Error("Failed to fetch images.");

        const data = await response.json();

        resultsContainer.innerHTML = "";

        if (data.results.length === 0) {
            resultsContainer.innerHTML = "<p>No images found.</p>";
            return;
        }

        data.results.forEach((image) => {
            const imgElement = document.createElement("img");
            imgElement.src = image.urls.small;
            imgElement.alt = image.alt_description || "Unsplash Image";
            resultsContainer.appendChild(imgElement);
        });
    } catch (error) {
        console.error("Error fetching images:", error);
        resultsContainer.innerHTML = "<p>Something went wrong. Try again later.</p>";
    }
}


if (document.getElementById("search-btn")) {
    const searchInput = document.getElementById("search-input");
    const searchBtn = document.getElementById("search-btn");

    searchBtn.addEventListener("click", () => {
        const query = searchInput.value.trim();
        if (query) {
            window.location.href = `results.html?query=${encodeURIComponent(query)}`;
        } else {
            alert("Please enter a destination to search!");
        }
    });
}

const searchQuery = getQueryParameter("query");
if (searchQuery) {
    fetchAndDisplayImages(searchQuery);
}

